from django.apps import AppConfig


class CalculatorConfig(AppConfig):
    name = 'calculator'
